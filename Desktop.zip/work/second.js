exports.data=function (){
    a*a;
}