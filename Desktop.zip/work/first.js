// var http = require('http');
// var url=require('url')
// http.createServer(function (req, res) {
//     res.writeHead(200, {'Content-Type': 'text/json'});
//     var q = url.parse(req.url, true).query;
//     var txt = q.year + " " + q.month;
//     res.write(txt)
//     res.end();
//   }).listen(8080); 
var http=require('http')
var fs=require('fs')
http.createServer(function(req,res){
  fs.readFile('./index.html', function(err,data){
    res.writeHead(200, {'Content-Type': 'text/html'})
    res.write(data)
    return res.end()
  })
}).listen(8080)

// const area = require('./second.js');
// area.data





var fs = require('fs');
var rs = fs.createReadStream('./demofile.txt');
rs.on('open', function () {
  console.log('The file is open');
}); 