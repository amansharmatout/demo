exports.area = function (a) {
    return a*a;
  }; 