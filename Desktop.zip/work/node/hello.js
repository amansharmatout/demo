const at = function (a, b) {
    if (a === void 0) { a = 18; }
    if (b === void 0) { b = 16; }
    console.log("value of a is " + a + " and value of b is " + b);
};
at(5, 6);
var msg = 'hello';
