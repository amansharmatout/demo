const http = require('http')
const os = require('os')
const uri=require('url')
const fs = require('fs')
var MongoClient = require('mongodb').MongoClient;
const { Console } = require('console');
var url = "mongodb://127.0.0.1:27017/";

http.createServer((req, res) => {
    console.log(req.url);
    res.writeHead(200, { 'Content-type': 'text/html' })
    if (req.url == '/') {

        fs.readFile('./list.html', (err, data) => {
            if (err) console.error(err);
            res.write(data);
            return res.end();
        })
    } else if (req.method == 'GET' && req.url == '/logout') {
        const user = { status: 'offline' };
        console.log(os.networkInterfaces().enp2s0[0].address);
        MongoClient.connect(url, function (err, db) {
            if (err) console.error(err);
            var dbo = db.db("Northwind");
            try {
                console.log(user);
                dbo.collection(`${os.networkInterfaces().enp2s0[0].address.toString}`).update({ _id: os.networkInterfaces().enp2s0[0].address }, user, (err, success) => {
                    if (err) {
                        console.error(err);
                        fs.readFile('./todo.html', (err, data) => {
                            if (err) console.error(err);
                            res.write(data);
                            return res.end();
                        })
                    }
                    db.close();
                    fs.readFile('./list.html', (err, data) => {
                        if (err) console.error(err);
                        res.write(data);
                        return res.end();
                    });

                });
            } catch (err) {
                console.error('Error : ',err);
            }
        });

    } else if (req.url == '/login' && req.method == 'POST') {
        req.on('data', (data) => {
            console.log(data.toString());
            data = data.toString();
            const user = { name: data.split('&')[0].split('=')[1], password: data.split('&')[1].split('=')[1], _id: os.networkInterfaces().enp2s0[0].address, status: 'online' };
            console.log(user, data.uname);
            console.log(os.networkInterfaces().enp2s0[0].address);
            MongoClient.connect(url, function (err, db) {
                if (err) console.error(err);
                var dbo = db.db("Northwind");
                try {
                    console.log(user);
                    dbo.collection(`${os.networkInterfaces().enp2s0[0].address.toString}`).insert(user, (err, success) => {
                        if (err) {
                            console.error(err);
                            fs.readFile('./list.html', (err, data) => {
                                if (err) console.error(err);
                                res.write(data);
                                return res.end();
                            })
                        }
                        db.close();
                        fs.readFile('./todo.html', (err, data) => {
                            if (err) console.error(err);
                            res.write(data);
                            return res.end();
                        });

                    });
                } catch (err) {

                }
            });
        });
    }
    else {
        res.writeHead(404, { 'Content-type': 'text/html' })
        res.write('404 Error : Not Found.');
        return res.end();
    }
}).listen(5000)